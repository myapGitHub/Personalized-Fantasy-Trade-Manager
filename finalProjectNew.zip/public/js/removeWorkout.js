const removeButtons = Array.from(document.getElementsByClassName("workoutRemove"))

removeButtons.forEach(button => {
    button.addEventListener("click", remove)
})

function remove(e) {
    try {
        fetch(`/workouts/${e.target.dataset.id}`, {
            method: "DELETE"
        })  
    } catch (error) {
        console.log(error.message)
    }
}