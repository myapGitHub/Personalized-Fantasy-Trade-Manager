// Changed DB name to workoutApp
export const mongoConfig = {
    serverUrl: 'mongodb://localhost:27017/',
    database: 'workoutApp'
  };
  
