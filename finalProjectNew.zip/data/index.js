import * as userDataFunctions from "./users.js";
import workoutsDataFunctions from "./workouts.js";

export const userData = userDataFunctions;
export const workoutData = workoutsDataFunctions;
